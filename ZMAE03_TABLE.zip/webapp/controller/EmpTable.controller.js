sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("MaheshZMAE03_TABLE.controller.EmpTable", {
		onInit: function() {
			var emptable = {
				"emp": [{
					"EmpId": 100,
					"EmpName": "Mahesh",
					"Degisnation": "Manager1",
					"Gender": "./Images/Female.png",
					"Smoker": true,
					"Status": "Married",
					"Rating":5
				}, {
					"EmpId": 101,
					"EmpName": "Mahesh K",
					"Degisnation": "Manager2",
					"Gender": "./Images/Female.png",
					"Smoker": true,
					"Status": "Married",
					"Rating":4.5
				}, {
					"EmpId": 102,
					"EmpName": "Mahesh Ku",
					"Degisnation": "Manager3",
					"Gender": "./Images/Female.png",
					"Smoker": false,
					"Status": "Married",
					"Rating":3.2
				}, {
					"EmpId": 103,
					"EmpName": "Mahesh Kum",
					"Degisnation": "Manager4",
					"Gender": "./Images/Female.png",
					"Smoker": true,
					"Status": "Single",
					"Rating":2
				}, {
					"EmpId": 104,
					"EmpName": "Mahesh Kuma",
					"Degisnation": "Manager5",
					"Gender": "./Images/Male.png",
					"Smoker": false,
					"Status": "Single",
					"Rating":3
				}]
			};
			//instantiate the Model
			var jsonmodelEmpdata = new JSONModel();
			jsonmodelEmpdata.setData(emptable);
			//Bind the model at CONTROL level WITH Refrence X (Three possibility Bind at Application/View/Control/)
			this.getView().byId("TABID").setModel(jsonmodelEmpdata, "X");
		}
	});
});